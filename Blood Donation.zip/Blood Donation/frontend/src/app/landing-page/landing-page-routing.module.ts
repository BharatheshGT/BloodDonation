import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LandingPageComponent } from './landing-page.component';
import { CreatePatientComponent } from './patient/create-patient/create-patient.component';
import { PatientListComponent } from './patient/patient-list/patient-list.component';
import { UpdatePatientComponent } from './patient/update-patient/update-patient.component';
import { CreateUserComponent } from './user/create-user/create-user.component';
import { UpdateUserComponent } from './user/update-user/update-user.component';
import { UserListComponent } from './user/user-list/user-list.component';



const routes: Routes = [
  {path: '', component: LandingPageComponent, children:[

    {path:'user-list', component:UserListComponent},
    {path:'create-user', component: CreateUserComponent},
    {path: 'update-user/:id', component: UpdateUserComponent},

   

    {path:'patient-list', component:PatientListComponent},
    {path:'create-patient', component: CreatePatientComponent},
    {path: 'update-patient/:id', component: UpdatePatientComponent},

    



  ]},



];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LandingPageRoutingModule { }
