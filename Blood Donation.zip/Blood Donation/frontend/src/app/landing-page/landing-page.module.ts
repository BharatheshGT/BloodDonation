import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LandingPageRoutingModule } from './landing-page-routing.module';
import { LandingPageComponent } from './landing-page.component';

import { CreateUserComponent } from './user/create-user/create-user.component';
import { UpdateUserComponent } from './user/update-user/update-user.component';
import { UserListComponent } from './user/user-list/user-list.component';
import { FormsModule } from '@angular/forms';
import { PatientListComponent } from './patient/patient-list/patient-list.component';
import { CreatePatientComponent } from './patient/create-patient/create-patient.component';

import { UpdatePatientComponent } from './patient/update-patient/update-patient.component';





@NgModule({
  declarations: [
    LandingPageComponent,

    CreateUserComponent,
    UpdateUserComponent,
    UserListComponent,
    PatientListComponent,
    CreatePatientComponent,

    UpdatePatientComponent,


  ],
  imports: [
    CommonModule,
    LandingPageRoutingModule,
    FormsModule,

  ]
})
export class LandingPageModule { }
